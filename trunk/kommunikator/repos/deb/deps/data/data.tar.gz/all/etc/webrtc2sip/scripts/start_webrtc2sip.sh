#!/bin/bash

sda_i=0

while true
do

    if [ $sda_i -gt 9 ]
    then
        echo "launch error"
        break
    fi


    if ps axu | grep -i "screen -dms webrtc2sip webrtc2sip" | grep -vq grep
    then
        echo "process is running"
        break
    else
        cd /etc/webrtc2sip/

        sudo screen -dmS webrtc2sip webrtc2sip


        sleep 3s
    fi


    let "sda_i++"

done